import React, { Component } from "react";
import "../../App.css";
import { credentials } from "../../db";

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.handleToUpdate = this.props.updateLogStateLOGIN;
  }
  async handleChange(e) {
    if (e.target.name == "password") {
      await this.setState({ password: e.target.value });
    } else {
      await this.setState({ username: e.target.value });
    }
    console.log(this.state);
  }
  async handleClick(e) {
    let thisReference = this;
    let name = "";
    let isValidCredentials = false;
    if (this.state.username.length < 3 || this.state.password.length < 4) {
      alert("Usuario y contrasena deben de tener mas de 3 caracteres");
      return;
    }
    Object.entries(credentials).forEach(function (k) {
      if (
        k[1].username == thisReference.state.username &&
        k[1].password == thisReference.state.password
      ) {
        name = k[1].nombre;
        isValidCredentials = true;
      }
    });
    if (isValidCredentials) {
      alert("Login exitoso");
      this.handleToUpdate(true, this.state.username, name);
    } else {
      alert("Usuario y/o contrasena equivocadas.");
      this.handleToUpdate(false, '', '');
    }
  }
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <form className="form-container">
            <label>Nombre Usuario</label>
            <br />

            <input name="username" type="text" onChange={this.handleChange} />
            <br />
            <label>Contrasena</label>
            <br />
            <input
              name="password"
              type="password"
              onChange={this.handleChange}
            />
            <br />
            <input type="button" onClick={this.handleClick} value="Entrar" />
          </form>
        </header>
      </div>
    );
  }
}
