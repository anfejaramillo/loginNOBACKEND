import React, { Component } from 'react'

export default class ProductCreate extends Component {
    render() {
        return (
            <div>
                Welcome to Create Product Page
            </div>
        )
    }
}
